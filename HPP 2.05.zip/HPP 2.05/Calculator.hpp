public static void Main(String[] args) {

    System.out.print Enter 1-st number

    var b = input()

    System.out.print Enter sign + or - or * or /

    var c = input()

    System.out.print Enter 2-nd number

    var a = input()

    var p = +
    var m = -
    var y = *
    var r = /

    System.out.print Result:
    if %c% == %p% : System.calc %b% + %a%
    var rp = res
    if %c% == %m% : System.calc %b% - %a%
    var rm = res
    if %c% == %y% : System.calc %b% * %a%
    var ry = res
    if %c% == %r% : System.calc %b% / %a%
    var rr = res

    if %c% == %p% : System.output %rp%
    if %c% == %m% : System.output %rm%
    if %c% == %y% : System.output %ry%
    if %c% == %r% : System.output %rr%

}